package org.apache.dubbo.demo.provider.test;

import org.apache.dubbo.rpc.*;

public class TestListener implements Filter.Listener {

    @Override
    public void onResponse(Result appResponse, Invoker<?> invoker, Invocation invocation) {
        System.out.println("onResponse=" + RpcContext.getContext().getAttachment("Seq"));
    }

    @Override
    public void onError(Throwable t, Invoker<?> invoker, Invocation invocation) {
        System.out.println("onError=" + RpcContext.getContext().getAttachment("Seq"));
    }
}
