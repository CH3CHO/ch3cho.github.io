package org.apache.dubbo.demo.provider.test;

import org.apache.dubbo.common.constants.CommonConstants;
import org.apache.dubbo.common.extension.Activate;
import org.apache.dubbo.rpc.*;

import java.util.concurrent.atomic.AtomicInteger;

@Activate(group = CommonConstants.CONSUMER, order = -9999)
public class TestConsumerFilter extends ListenableFilter {

    private final AtomicInteger seq = new AtomicInteger();

    @Override
    public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
        String currentSeq = String.valueOf(seq.incrementAndGet());
        System.out.println("invoke=" + currentSeq);
        RpcContext.getContext().setAttachment("Seq", currentSeq);

        return invoker.invoke(invocation);
    }

    @Override
    public Listener listener(Invocation invocation) {
        Listener listener = super.listener(invocation);
        if (listener == null) {
            return listener();
        }
        return listener;
    }

    @Override
    public Listener listener() {
        return new TestListener();
    }
}
